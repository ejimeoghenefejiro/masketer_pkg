#  `mustafa` Analysis Demo

## Overview
*(Short Explanation: This section provides a brief summary of the project.)*

This repository contains a Jupyter notebook demonstrating the initial functionality of the **`mustafa`** Python library for financial and market data analysis. The notebook currently implements an interactive workflow to:

1.  Prompt the user to select an analysis focus (**Country** or **Sector**).
2.  Specify the target country and sector (demonstrated with **UK** and **Oil & Gas** in the example run).
3.  Load and plot relevant master data for the selected parameters.

---

## Prerequisites
*(Short Explanation: This lists the software needed to run the project.)*

To run this notebook, you need the following installed:

* **Python** (The original execution environment used Python 3.14)
* **Jupyter Notebook** or **JupyterLab**

---

## Installation
*(Short Explanation: These are the commands to get the required Python packages.)*

The core library, `mustafa`, is installed from the **TestPyPI** 

Use the following commands to install the required packages:

```bash
# Install the mustafa library from TestPyPI
# in a Jupyter cell
!pip install -q -i https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple mustafa[notebook]
```
Usage
1. Data Files
For the notebook to execute successfully, the following files must be placed in the same folder as the projectname.ipynb file:
UK_Share Price_Combined.xlsx,SP
Tic_Global.xlsx,(Default sheet)
Hello! That's a great way to make the README even more useful by showing the actual code flow.Here is the complete README.md formatted in markdown, incorporating the Core Notebook Logic and all previously requested details:Markdown# First Library Test Work: `mustafa` Analysis Demo

## Overview
*(Short Explanation: This section provides a brief summary of the project.)*

This repository contains a Jupyter notebook demonstrating the initial functionality of the **`mustafa`** Python library for financial and market data analysis. The notebook currently implements an interactive workflow to:

1.  Prompt the user to select an analysis focus (**Country** or **Sector**).
2.  Specify the target country and sector (demonstrated with **UK** and **Oil & Gas** in the example run).
3.  Load and plot relevant master data for the selected parameters.

---

## Prerequisites
*(Short Explanation: This lists the software needed to run the project.)*

To run this notebook, you need the following installed:

* **Python** (The original execution environment used Python 3.14)
* **Jupyter Notebook** or **JupyterLab**


```bash
#interactive
import mustafa as m
import mustafa.core as core   # exposes the module-level globals

# Step 1: interactive prompts
x, countryname = m.hello()

# Step 2: push into module state so other funcs “see” them
core.x = x
core.countryname = countryname

# Step 3: load + plot (creates the Excel outputs and charts)
rdata, df0 = m.master_data()
x, R, S = m.charts()
```

```bash

#Non-interactive sector (if you already know the sector)
import mustafa as m
import mustafa.core as core

# Set country and load data (no prompts)
core.countryname = "UK"
rdata, df0 = m.master_data()

# Choose a sector and compute returns/summary just for that sector
sector = "Oil & Gas"
tickers = list(df0.loc[df0["Sector"] == sector, "Ticker"])
cols = [t for t in tickers if t in rdata.columns]

R2 = rdata[cols].pct_change(fill_method=None)
S2 = pd.DataFrame(R2.describe(percentiles=[0.01, 0.10, 0.50, 0.90, 0.99]))

# Charts
m.KPIs(R2, S2, sector=sector, ticker=tickers)
m.corr_ana(R2, sector=sector, rdata=rdata)

```
3.Execution Steps
 These are the steps to run this in jupyter notebook.
 1. Launch your Jupyter environment.
 2. Create a new project and copy the code above. Note the code is in two form interactive and non interactive, copy to different cell on jupyter note.
 3. Ensure the required data files (listed above) are in the current folder.
 4. Execute the cells sequentially, providing input when prompted.
